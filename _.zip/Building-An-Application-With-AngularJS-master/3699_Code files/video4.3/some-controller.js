angular.module('SampleApp')
	.controller('SomeController', function($scope){
		$scope.title = 'Hello World';
	});