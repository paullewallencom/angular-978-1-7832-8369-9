var app = angular.module('SampleApp', []);

app.controller('MyController', function($injector){
	
	var win = $injector.get('$windows');

})