var app = angular.module('app',[]);
app.controller('Main', function($scope){
	$scope.name = 'John Doe';
});
