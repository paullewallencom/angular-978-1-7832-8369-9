describe('testing the main controller', function(){
	describe('when creating a new controller', function(){

		beforeEach(function(){

		});

		afterEach(function(){

		});

		it('should set the title...', function(){
			//arrange
			//act
			//assert
		})

		it('should load the list of languages', function(){

		})

		it('should calculate the number of cards', function(){

			it('should do something interesting...', function(){
				expect(count).toBe(10);
				expect(name).toEqual('foo');
				expect(message).toMatch(/hello/);	
				
				expect(message).not.toMatch('world/');			
			})
		})
	})

	describe('when clicking the save button', function(){

	})
});